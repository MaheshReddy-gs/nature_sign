/** @type {import('tailwindcss').Config} */
export default {
  theme: {
    extend: {
      colors: {
        ORANGE: '#f97316',
      },
    },
  },
}
